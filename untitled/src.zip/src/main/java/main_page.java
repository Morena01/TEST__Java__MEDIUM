import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class main_page {

    private WebDriver driver;
    public main_page(WebDriver driver) {
        this.driver = driver;
    }
    private By weather = By.cssSelector(".informers3__item-icon");   //кнопка погоды взятая из f12

    public Weather SelectWeather() {
        driver.findElement(weather).click();
        return new Weather(driver);
    }
}
