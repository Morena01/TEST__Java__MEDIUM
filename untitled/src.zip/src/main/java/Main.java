import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Main {
    public static void main(String[] args) {
        System.setProperty("webdriver.geckodriver", "/home/lipsi/geckodriver");
        WebDriver driver = new FirefoxDriver();
        driver.get("http://ya.ru");
        driver.quit();
    }


}
