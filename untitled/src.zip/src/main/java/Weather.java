import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Weather {
    WebDriver driver = new FirefoxDriver();
    public Weather(WebDriver driver) {
        this.driver = driver;
    }
    private By title = By.cssSelector("#main_title");

    public String getTitle() {
        return driver.findElement(title).getText();
    }
}
