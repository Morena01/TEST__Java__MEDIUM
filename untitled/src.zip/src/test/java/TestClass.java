import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestClass {
    public static Weather MainPage;

    @Before
    public static void setUp() {
        System.setProperty("webdriver.geckodriver", "/home/lipsi/geckodriver");  // запуск драйвера мозила фокс
        FirefoxDriver driver = new FirefoxDriver();
        driver.get("http://ya.ru");    // сайт который мы тестируме
    }

    @Test
    public void CheckWeather() {
        Weather mainPage = MainPage.SelectWeather();
        String weatherTitle = mainPage.getTitle();
        Assert.assertEquals("Село Пристанское", weatherTitle);
    }



    @After
    public static void tearDown() {
        driver.quit();
    }     //выйти из драйвера (браузера)
}
